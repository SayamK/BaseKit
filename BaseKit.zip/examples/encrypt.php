<?php 
require '../lib/classes.php';

$basekit = new BaseKit;

echo $basekit->specialEncrypt("BaseKit");


?>